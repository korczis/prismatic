
defmodule Prismatic.Document.Metadata do
  @moduledoc """
  Metadata extracted from the filesystem or enrichers about a file/document.
  """

  @type t :: %__MODULE__{
          filename: String.t(),
          extension: String.t() | nil,
          dirname: String.t(),
          path: String.t(),
          hidden?: boolean(),
          size: non_neg_integer(),
          ctime: :calendar.datetime(),
          mtime: :calendar.datetime(),
          uid: integer(),
          gid: integer(),
          nlink: integer(),
          mode: integer(),
          sha256: String.t() | nil,
          md5: String.t() | nil,
          mime_type: String.t() | nil,
          charset: String.t() | nil,
          tags: [String.t()] | nil,
          source: String.t() | nil,
          indexed_at: DateTime.t() | nil
        }

  defstruct [
    :filename, :extension, :dirname, :path,
    :hidden?, :size, :ctime, :mtime, :uid,
    :gid, :nlink, :mode, :sha256, :md5,
    :mime_type, :charset, :tags, :source, :indexed_at
  ]
end
